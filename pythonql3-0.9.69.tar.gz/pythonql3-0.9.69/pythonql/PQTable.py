class PQTable:
  def __init__(self,schema):
    self.schema = schema
    self.data = []
